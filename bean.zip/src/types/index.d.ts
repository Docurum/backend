/* eslint-disable no-var */

declare global {
  var appRoot: string;
}

export {};
