declare module "xss-clean" {
  const value: Function;

  export default value;
}
