export { default as authRoutes } from "./Auth.route";
export { default as forumRoutes } from "./Forum.route";
export { default as userRoutes } from "./User.route";
export { default as clinicRoutes } from "./Clinic.route";
